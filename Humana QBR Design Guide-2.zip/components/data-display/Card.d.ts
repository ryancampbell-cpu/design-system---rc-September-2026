import * as React from "react";

/**
 * H1 Card — flat editorial container with an optional media tile.
 *
 * @startingPoint section="Data display" subtitle="Media + eyebrow + title" viewport="700x400"
 */
export interface CardProps extends Omit<React.HTMLAttributes<HTMLElement>, "title"> {
  variant?: "outline" | "subtle" | "invert";
  media?: string;
  mediaAlt?: string;
  eyebrow?: React.ReactNode;
  title?: React.ReactNode;
  footer?: React.ReactNode;
  href?: string;
  onClick?: (e: React.MouseEvent) => void;
  padding?: string;
  children?: React.ReactNode;
}
export function Card(props: CardProps): JSX.Element;
