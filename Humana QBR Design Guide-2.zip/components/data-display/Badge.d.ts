import * as React from "react";

/**
 * H1 Badge — sharp-cornered caps-tracked status label.
 */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: "sapphire" | "plum" | "neutral";
  variant?: "solid" | "soft" | "outline";
  children?: React.ReactNode;
}
export function Badge(props: BadgeProps): JSX.Element;
