# Card

Editorial container. Optional media tile is the one place rounded corners appear.

```jsx
<Card
  variant="outline"
  media="/assets/photo.jpg"
  eyebrow="Trial"
  title="Provider intelligence"
>
  Publications, trials, claims and affiliations resolved to one profile.
</Card>
```

Variants: `outline` (white + silver border, default), `subtle` (white-smoke), `invert` (sapphire — one or two per view).
