import React from "react";

/**
 * H1 Card — flat editorial container. White surface, 1px silver border, sharp
 * corners, no shadow. Optional media tile uses the brand's photography radius.
 */
export function Card({
  variant = "outline",
  media, mediaAlt = "",
  eyebrow, title,
  children, footer,
  href, onClick,
  padding = "var(--space-small)",
  style,
  ...rest
}) {
  const Tag = href ? "a" : "div";
  const surfaces = {
    outline: { background: "var(--surface-card)",   border: "1px solid var(--border-default)", color: "var(--text-body)" },
    subtle:  { background: "var(--surface-subtle)", border: "1px solid var(--surface-subtle)", color: "var(--text-body)" },
    invert:  { background: "var(--surface-invert)", border: "1px solid var(--surface-invert)", color: "var(--text-inverse)" },
  };
  const clickable = !!(href || onClick);
  return (
    <Tag
      {...rest}
      href={href}
      onClick={onClick}
      style={{
        display: "flex", flexDirection: "column",
        borderRadius: "var(--radius-none)",
        overflow: "hidden", textDecoration: "none",
        transition: "opacity var(--duration-base) var(--ease-standard)",
        cursor: clickable ? "pointer" : "default",
        ...surfaces[variant], ...style,
      }}
      onMouseEnter={clickable ? (e) => (e.currentTarget.style.opacity = "0.85") : undefined}
      onMouseLeave={clickable ? (e) => (e.currentTarget.style.opacity = "1") : undefined}
    >
      {media && (
        <div style={{ padding, paddingBottom: 0 }}>
          <img src={media} alt={mediaAlt}
               style={{ width: "100%", display: "block", borderRadius: "var(--radius-photo)", objectFit: "cover" }} />
        </div>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem", padding }}>
        {eyebrow && (
          <span style={{
            fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)",
            letterSpacing: "var(--tracking-caps)", textTransform: "uppercase",
            color: variant === "invert" ? "var(--color-blue-200)" : "var(--color-sapphire)",
          }}>{eyebrow}</span>
        )}
        {title && (
          <h4 style={{
            margin: 0, fontFamily: "var(--font-display)",
            fontSize: "var(--text-h4)", fontWeight: 400,
            color: variant === "invert" ? "var(--color-white)" : "var(--text-heading)",
          }}>{title}</h4>
        )}
        {children && (
          <div style={{
            fontFamily: "var(--font-body)", fontSize: "var(--text-base)",
            lineHeight: "var(--leading-normal)",
            color: variant === "invert" ? "rgba(255,255,255,0.85)" : "var(--text-body)",
          }}>{children}</div>
        )}
        {footer && <div style={{ marginTop: "0.5rem" }}>{footer}</div>}
      </div>
    </Tag>
  );
}
