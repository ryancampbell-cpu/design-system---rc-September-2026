import React from "react";

/**
 * H1 Quote — editorial pull quote. Serif GT Sectra italic with a thick left rule.
 */
export function Quote({ children, cite, author, accent = "ink", style, ...rest }) {
  const ruleColor =
    accent === "sapphire" ? "var(--color-sapphire)"
    : accent === "plum"   ? "var(--color-plum)"
    : "var(--color-black)";
  return (
    <figure {...rest} style={{ margin: 0, ...style }}>
      <blockquote style={{
        margin: 0, borderLeft: `3px solid ${ruleColor}`,
        padding: "0.75rem 1.25rem",
        fontFamily: "var(--font-serif)", fontStyle: "italic",
        fontSize: "var(--text-h4)", lineHeight: 1.5,
        color: "var(--text-heading)",
      }}>{children}</blockquote>
      {(author || cite) && (
        <figcaption style={{
          marginTop: "0.75rem", paddingLeft: "1.25rem",
          fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)",
          color: "var(--text-muted)",
        }}>
          {author && <span style={{ color: "var(--text-strong)" }}>{author}</span>}
          {author && cite && " · "}
          {cite}
        </figcaption>
      )}
    </figure>
  );
}
