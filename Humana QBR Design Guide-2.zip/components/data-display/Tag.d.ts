import * as React from "react";
/** H1 Tag — rounded pill chip, softer than Badge. */
export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: "neutral" | "sapphire";
  onRemove?: (e: React.MouseEvent) => void;
  children?: React.ReactNode;
}
export function Tag(props: TagProps): JSX.Element;
