# Tag

Rounded pill for categories / applied filters.

```jsx
<Tag>Oncology</Tag>
<Tag tone="sapphire" onRemove={() => remove(id)}>Clinical trials</Tag>
```
