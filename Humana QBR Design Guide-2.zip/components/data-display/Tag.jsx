import React from "react";

/**
 * H1 Tag — rounded category chip, optionally removable. Softer than Badge;
 * uses the pill radius and neutral or sapphire tinting.
 */
export function Tag({ tone = "neutral", onRemove, children, style, ...rest }) {
  const palette = tone === "sapphire"
    ? { bg: "var(--color-blue-50)", fg: "var(--color-blue-900)", br: "var(--color-blue-200)" }
    : { bg: "var(--color-white)",   fg: "var(--text-body)",       br: "var(--border-default)" };
  return (
    <span {...rest} style={{
      display: "inline-flex", alignItems: "center", gap: "0.375rem",
      padding: "0.3125rem 0.75rem",
      fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", lineHeight: 1.2,
      color: palette.fg, background: palette.bg,
      border: `1px solid ${palette.br}`,
      borderRadius: "var(--radius-pill)",
      ...style,
    }}>
      {children}
      {onRemove && (
        <button type="button" onClick={onRemove} aria-label="Remove"
          style={{
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            width: "1rem", height: "1rem", padding: 0, border: "none",
            background: "transparent", color: "currentColor", cursor: "pointer", opacity: 0.7,
          }}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>
      )}
    </span>
  );
}
