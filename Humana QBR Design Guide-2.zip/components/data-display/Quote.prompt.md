# Quote

Editorial pull quote. Use sparingly.

```jsx
<Quote author="H1 Brand Hub" cite="brand.h1.co" accent="sapphire">
  Connecting the world with the right doctors.
</Quote>
```
