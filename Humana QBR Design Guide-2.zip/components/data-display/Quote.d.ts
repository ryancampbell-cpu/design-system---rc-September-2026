import * as React from "react";

/** H1 Quote — editorial pull quote (GT Sectra italic, thick left rule). */
export interface QuoteProps extends React.HTMLAttributes<HTMLElement> {
  cite?: React.ReactNode;
  author?: React.ReactNode;
  accent?: "ink" | "sapphire" | "plum";
  children?: React.ReactNode;
}
export function Quote(props: QuoteProps): JSX.Element;
