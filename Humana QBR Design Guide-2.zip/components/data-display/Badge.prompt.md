# Badge

Compact status label — caps-tracked, sharp corners.

```jsx
<Badge>Oncology</Badge>
<Badge tone="plum" variant="solid">Clinical trial</Badge>
<Badge variant="outline">Draft</Badge>
```
