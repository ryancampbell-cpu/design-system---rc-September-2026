import React from "react";

const tones = {
  sapphire: { solid: ["var(--color-sapphire)", "#fff"], soft: ["var(--color-blue-50)", "var(--color-blue-900)"], outline: ["transparent", "var(--color-sapphire)"] },
  plum:     { solid: ["var(--color-plum)", "#fff"],     soft: ["var(--color-plum-50)", "var(--color-plum-900)"], outline: ["transparent", "var(--color-plum)"] },
  neutral:  { solid: ["var(--color-neutral-900)", "#fff"], soft: ["var(--color-neutral-100)", "var(--color-neutral-900)"], outline: ["transparent", "var(--color-neutral-900)"] },
};

/**
 * H1 Badge — compact caps-tracked status label. Tones follow the brand ramps;
 * `solid` fills, `soft` tints, `outline` uses a hairline border.
 */
export function Badge({ tone = "sapphire", variant = "soft", children, style, ...rest }) {
  const [bg, fg] = (tones[tone] || tones.sapphire)[variant];
  return (
    <span
      {...rest}
      style={{
        display: "inline-flex", alignItems: "center", gap: "0.375rem",
        padding: "0.25rem 0.625rem",
        fontFamily: "var(--font-sans)", fontSize: "var(--text-xs)",
        letterSpacing: "var(--tracking-caps)", textTransform: "uppercase", lineHeight: 1.4,
        color: fg, background: bg,
        border: variant === "outline" ? `1px solid ${fg}` : "1px solid transparent",
        borderRadius: "var(--radius-none)",
        ...style,
      }}
    >
      {children}
    </span>
  );
}
