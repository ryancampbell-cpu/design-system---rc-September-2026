# Radio
6px ink ring on select.
```jsx
<Radio label="All years" name="years" value="all" checked={value === "all"} onChange={onChange} />
```
