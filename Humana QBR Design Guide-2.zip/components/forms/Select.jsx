import React, { useState } from "react";

/** H1 select — native select styled to match the input system. */
export function Select({ label, hint, error, id, children, disabled, style, ...rest }) {
  const [focus, setFocus] = useState(false);
  const inputId = id || (label ? `sel-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return (
    <div style={{ width: "100%" }}>
      {label && (
        <label htmlFor={inputId} style={{
          display: "block", marginBottom: "0.5rem",
          fontFamily: "var(--font-sans)", fontSize: "var(--text-base)",
          color: "var(--text-strong)",
        }}>{label}</label>
      )}
      <div style={{ position: "relative" }}>
        <select {...rest} id={inputId} disabled={disabled}
          onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          style={{
            width: "100%", minHeight: "2.75rem",
            padding: "0.5rem 2.25rem 0.5rem 0.75rem",
            fontFamily: "var(--font-sans)", fontSize: "var(--text-base)",
            color: "var(--text-strong)",
            background: disabled ? "var(--color-neutral-100)" : "var(--color-white)",
            border: `1px solid ${error ? "var(--color-plum)" : "var(--color-black)"}`,
            borderRadius: "var(--radius-none)", outline: "none",
            appearance: "none", WebkitAppearance: "none",
            boxShadow: focus ? "0 0 0 2px var(--color-blue-200)" : "none",
            boxSizing: "border-box",
            cursor: disabled ? "not-allowed" : "pointer",
            ...style,
          }}>{children}</select>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
             style={{ position: "absolute", right: "0.75rem", top: "50%",
                      transform: "translateY(-50%)", pointerEvents: "none",
                      color: "var(--text-strong)" }}>
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </div>
      {error ? (
        <div style={{ marginTop: "0.375rem", fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", color: "var(--color-plum)" }}>{error}</div>
      ) : hint ? (
        <div style={{ marginTop: "0.375rem", fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>{hint}</div>
      ) : null}
    </div>
  );
}
