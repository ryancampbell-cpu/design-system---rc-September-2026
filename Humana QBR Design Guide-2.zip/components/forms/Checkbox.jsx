import React, { useState } from "react";

/** H1 checkbox — sharp 1.125rem box, 1px ink border, fills solid ink when checked. */
export function Checkbox({ label, checked, defaultChecked, onChange, disabled, id, ...rest }) {
  const inputId = id || (label ? `cb-${String(label).replace(/\s+/g, "-").toLowerCase()}` : undefined);
  const isControlled = checked !== undefined;
  const [internal, setInternal] = useState(!!defaultChecked);
  const on = isControlled ? checked : internal;
  const toggle = (e) => {
    if (disabled) return;
    if (!isControlled) setInternal(e.target.checked);
    onChange && onChange(e);
  };
  return (
    <label htmlFor={inputId} style={{
      display: "inline-flex", alignItems: "center", gap: "0.75rem",
      cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-sans)", fontSize: "var(--text-base)", color: "var(--text-strong)",
    }}>
      <span style={{ position: "relative", display: "inline-flex", flex: "0 0 auto" }}>
        <input {...rest} id={inputId} type="checkbox" checked={on} onChange={toggle} disabled={disabled}
          style={{ position: "absolute", opacity: 0, width: 0, height: 0 }} />
        <span style={{
          width: "1.125rem", height: "1.125rem",
          border: "1px solid var(--color-black)", borderRadius: "var(--radius-none)",
          background: on ? "var(--color-black)" : "var(--color-white)",
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          transition: "background var(--duration-fast) var(--ease-standard)",
        }}>
          {on && (
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
                 stroke="var(--color-white)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          )}
        </span>
      </span>
      {label && <span>{label}</span>}
    </label>
  );
}
