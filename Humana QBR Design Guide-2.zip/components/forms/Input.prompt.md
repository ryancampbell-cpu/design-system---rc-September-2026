# Input / Textarea

Sharp corners, 1px ink border, sans-serif UI type. Focus ring is blue-200.

```jsx
<Input label="Provider name" placeholder="Search 10M+ HCPs" hint="Sharp corners, 1px ink border." />
<Input label="Institution" placeholder="Required" error="This field is required." />
<Textarea label="Notes" rows={3} placeholder="Context for the engagement" />
```
