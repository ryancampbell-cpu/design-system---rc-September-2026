import React, { useState } from "react";

const fieldLabel = {
  display: "block", marginBottom: "0.5rem",
  fontFamily: "var(--font-sans)", fontSize: "var(--text-base)", fontWeight: 400,
  color: "var(--text-strong)",
};
const hintStyle  = { marginTop: "0.375rem", fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", color: "var(--text-muted)" };
const errorStyle = { marginTop: "0.375rem", fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", color: "var(--color-plum)" };

/** H1 text input — sharp corners, 1px ink border, sans-serif UI type. */
export function Input({ label, hint, error, id, type = "text", disabled, style, ...rest }) {
  const [focus, setFocus] = useState(false);
  const inputId = id || (label ? `in-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return (
    <div style={{ width: "100%" }}>
      {label && <label htmlFor={inputId} style={fieldLabel}>{label}</label>}
      <input {...rest} id={inputId} type={type} disabled={disabled}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{
          width: "100%", minHeight: "2.75rem", padding: "0.5rem 0.75rem",
          fontFamily: "var(--font-sans)", fontSize: "var(--text-base)", lineHeight: 1.6,
          color: "var(--text-strong)",
          background: disabled ? "var(--color-neutral-100)" : "var(--color-white)",
          border: `1px solid ${error ? "var(--color-plum)" : "var(--color-black)"}`,
          borderRadius: "var(--radius-none)", outline: "none",
          boxShadow: focus ? "0 0 0 2px var(--color-blue-200)" : "none",
          boxSizing: "border-box",
          ...style,
        }} />
      {error ? <div style={errorStyle}>{error}</div> : hint ? <div style={hintStyle}>{hint}</div> : null}
    </div>
  );
}

/** H1 textarea — matches Input, taller default. */
export function Textarea({ label, hint, error, id, rows = 5, disabled, style, ...rest }) {
  const [focus, setFocus] = useState(false);
  const inputId = id || (label ? `ta-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return (
    <div style={{ width: "100%" }}>
      {label && <label htmlFor={inputId} style={fieldLabel}>{label}</label>}
      <textarea {...rest} id={inputId} rows={rows} disabled={disabled}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{
          width: "100%", minHeight: "11.25rem", padding: "0.75rem",
          fontFamily: "var(--font-sans)", fontSize: "var(--text-base)", lineHeight: 1.6,
          color: "var(--text-strong)",
          background: disabled ? "var(--color-neutral-100)" : "var(--color-white)",
          border: `1px solid ${error ? "var(--color-plum)" : "var(--color-black)"}`,
          borderRadius: "var(--radius-none)", outline: "none",
          resize: "vertical",
          boxShadow: focus ? "0 0 0 2px var(--color-blue-200)" : "none",
          boxSizing: "border-box",
          ...style,
        }} />
      {error ? <div style={errorStyle}>{error}</div> : hint ? <div style={hintStyle}>{hint}</div> : null}
    </div>
  );
}
