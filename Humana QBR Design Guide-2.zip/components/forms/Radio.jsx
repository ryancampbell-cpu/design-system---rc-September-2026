import React from "react";

/**
 * H1 radio — 1.125rem round control; selection is a thick ink ring (6px border)
 * around a white center, matching the brand hub.
 */
export function Radio({ label, checked, name, value, onChange, disabled, id, ...rest }) {
  const inputId = id || (value ? `rd-${String(value).replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return (
    <label htmlFor={inputId} style={{
      display: "inline-flex", alignItems: "center", gap: "0.75rem",
      cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-sans)", fontSize: "var(--text-base)", color: "var(--text-strong)",
    }}>
      <span style={{ position: "relative", display: "inline-flex", flex: "0 0 auto" }}>
        <input {...rest} id={inputId} type="radio" name={name} value={value}
          checked={checked} onChange={onChange} disabled={disabled}
          style={{ position: "absolute", opacity: 0, width: 0, height: 0 }} />
        <span style={{
          width: "1.125rem", height: "1.125rem",
          borderRadius: "var(--radius-pill)", background: "var(--color-white)",
          border: checked ? "6px solid var(--color-black)" : "1px solid var(--color-black)",
          boxSizing: "border-box",
          transition: "border-width var(--duration-fast) var(--ease-standard)",
        }} />
      </span>
      {label && <span>{label}</span>}
    </label>
  );
}
