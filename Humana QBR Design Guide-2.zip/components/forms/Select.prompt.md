# Select
Native select in the sharp-cornered ink-border style.
```jsx
<Select label="Therapeutic area">
  <option>Oncology</option>
  <option>Cardiology</option>
</Select>
```
