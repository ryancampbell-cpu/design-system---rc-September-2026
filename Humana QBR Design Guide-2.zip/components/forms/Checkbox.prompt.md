# Checkbox
Sharp square, fills ink when checked.
```jsx
<Checkbox label="Include affiliations" defaultChecked />
```
