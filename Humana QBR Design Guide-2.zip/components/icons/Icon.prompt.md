# Icon

Renders a glyph from the H1 secondary icon set by CSS-masking a PNG. Inherits any brand color.

```jsx
<Icon name="search" size={28} color="var(--color-sapphire)" />
<Icon name="calendar" size={20} color="var(--color-plum)" />
```

The commercial H1 icon set is not shipped here — drop your PNGs into `assets/icons/` (or set `basePath`).
