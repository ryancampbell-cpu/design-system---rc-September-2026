import React from "react";

/**
 * H1 Icon — renders a glyph from the H1 secondary icon set by CSS-masking a
 * PNG. Icons inherit color from any brand token (currentColor by default).
 * `basePath` points at the folder of PNG glyphs relative to the page.
 *
 * NOTE: The commercial H1 icon PNGs are not shipped in this open kit. Drop
 * your `name`.png files into `assets/icons/` or override `basePath`.
 */
export function Icon({
  name,
  size = 24,
  color = "currentColor",
  basePath = "assets/icons/",
  title,
  style,
  ...rest
}) {
  const url = `${basePath}${name}.png`;
  return (
    <span
      {...rest}
      role="img"
      aria-label={title || name}
      title={title}
      style={{
        display: "inline-block",
        width: size, height: size, flex: "none",
        backgroundColor: color,
        WebkitMaskImage: `url("${url}")`, maskImage: `url("${url}")`,
        WebkitMaskRepeat: "no-repeat", maskRepeat: "no-repeat",
        WebkitMaskPosition: "center", maskPosition: "center",
        WebkitMaskSize: "contain", maskSize: "contain",
        ...style,
      }}
    />
  );
}
