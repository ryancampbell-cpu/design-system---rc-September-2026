import * as React from "react";
export interface IconProps extends React.HTMLAttributes<HTMLSpanElement> {
  name: string;
  size?: number | string;
  color?: string;
  basePath?: string;
  title?: string;
}
export function Icon(props: IconProps): JSX.Element;
