# Button

Editorial sharp-cornered button. Solid ink `primary`, `secondary` outline, `tertiary` inline link. Add `invert` on sapphire / dark fields.

```jsx
<Button href="/browse">Browse HCPs</Button>
<Button variant="secondary">Filter</Button>
<Button variant="tertiary">See all →</Button>
<Button invert>Learn more</Button>
```

Sizes: `medium` (default, 44px) · `small` (32px). `disabled` dims to 40%. Hover dims to 0.8 across 0.25s.
