import * as React from "react";

/**
 * H1 Button — sharp-cornered editorial button. Solid ink primary, outline
 * secondary, or inline tertiary link. Pair `invert` with saturated fields.
 *
 * @startingPoint section="Buttons" subtitle="Primary, secondary, tertiary" viewport="700x220"
 */
export interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "type"> {
  /** Visual style — solid, outlined, or inline text link. */
  variant?: "primary" | "secondary" | "tertiary";
  /** `medium` (default) or compact `small`. */
  size?: "small" | "medium";
  /** Flip colors for use on sapphire / dark fields. */
  invert?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  iconPosition?: "left" | "right";
  /** Override the rendered tag; defaults to `a` when `href` is set, else `button`. */
  as?: keyof JSX.IntrinsicElements;
  href?: string;
  type?: "button" | "submit" | "reset";
  onClick?: (e: React.MouseEvent) => void;
  children?: React.ReactNode;
}

export function Button(props: ButtonProps): JSX.Element;
