import React from "react";

/**
 * H1 Button — editorial, sharp-cornered, 1px border. Variants: primary (solid
 * ink), secondary (outline), tertiary (inline text link). `invert` flips
 * colors for use on saturated brand fields.
 */
export function Button({
  variant = "primary",
  size = "medium",
  invert = false,
  disabled = false,
  icon = null,
  iconPosition = "right",
  as,
  href,
  type = "button",
  onClick,
  children,
  style,
  ...rest
}) {
  const Tag = as || (href ? "a" : "button");
  const pad = size === "small" ? "0.5rem 1.25rem"
    : variant === "tertiary" ? "0.5rem 0"
    : "0.75rem 1.5rem";
  const base = {
    display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "0.5rem",
    fontFamily: "var(--font-sans)",
    fontSize: size === "small" ? "var(--text-sm)" : "var(--text-base)",
    fontWeight: 400, lineHeight: 1, textAlign: "center", textDecoration: "none",
    borderRadius: "var(--radius-none)",
    border: "1px solid transparent",
    padding: pad,
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.4 : 1,
    transition: "opacity var(--duration-base) var(--ease-standard), background-color var(--duration-base) var(--ease-standard)",
    whiteSpace: "nowrap",
    boxSizing: "border-box",
  };
  const variants = {
    primary: invert
      ? { background: "var(--color-white)", color: "var(--color-black)", borderColor: "var(--color-white)" }
      : { background: "var(--color-black)", color: "var(--color-white)", borderColor: "var(--color-black)" },
    secondary: invert
      ? { background: "transparent", color: "var(--color-white)", borderColor: "var(--color-white)" }
      : { background: "transparent", color: "var(--color-black)", borderColor: "var(--color-black)" },
    tertiary: {
      background: "transparent",
      color: invert ? "var(--color-white)" : "var(--text-link)",
      borderColor: "transparent",
      padding: pad,
    },
  };
  const styles = { ...base, ...variants[variant], ...style };
  const onEnter = (e) => { if (!disabled) e.currentTarget.style.opacity = "0.8"; };
  const onLeave = (e) => { if (!disabled) e.currentTarget.style.opacity = "1"; };
  return (
    <Tag
      {...rest}
      href={href}
      type={Tag === "button" ? type : undefined}
      onClick={disabled ? undefined : onClick}
      aria-disabled={disabled || undefined}
      style={styles}
      onMouseEnter={onEnter}
      onMouseLeave={onLeave}
    >
      {icon && iconPosition === "left" && <span style={{ display: "inline-flex" }}>{icon}</span>}
      {children}
      {icon && iconPosition === "right" && <span style={{ display: "inline-flex" }}>{icon}</span>}
    </Tag>
  );
}
