import * as React from "react";
export interface TabItem { id: string; label: React.ReactNode; content?: React.ReactNode; }
export interface TabsProps extends React.HTMLAttributes<HTMLDivElement> {
  items?: TabItem[];
  value?: string;
  defaultValue?: string;
  onChange?: (id: string) => void;
}
export function Tabs(props: TabsProps): JSX.Element;
