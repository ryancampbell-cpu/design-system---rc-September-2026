import React, { useState } from "react";

/**
 * H1 Tabs — underline tab bar: muted labels, 2px ink underline on the active
 * tab, horizontal scroll when crowded.
 */
export function Tabs({ items = [], value, defaultValue, onChange, style, ...rest }) {
  const isControlled = value !== undefined;
  const [internal, setInternal] = useState(defaultValue ?? items[0]?.id);
  const active = isControlled ? value : internal;
  const select = (id) => {
    if (!isControlled) setInternal(id);
    onChange && onChange(id);
  };
  const activeItem = items.find((t) => t.id === active);
  return (
    <div {...rest} style={style}>
      <div style={{
        display: "flex", gap: "1.5rem",
        borderBottom: "1px solid rgba(0,0,0,0.15)",
        overflowX: "auto",
      }}>
        {items.map((t) => {
          const on = t.id === active;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => select(t.id)}
              style={{
                flex: "none", padding: "0.5rem 0",
                background: "transparent", border: "none",
                borderBottom: `2px solid ${on ? "var(--color-black)" : "transparent"}`,
                marginBottom: "-1px",
                fontFamily: "var(--font-sans)", fontSize: "var(--text-base)",
                color: on ? "var(--color-black)" : "rgba(0,0,0,0.55)",
                cursor: "pointer",
                transition: "color var(--duration-base) var(--ease-standard)",
                whiteSpace: "nowrap",
              }}
            >
              {t.label}
            </button>
          );
        })}
      </div>
      {activeItem?.content !== undefined && (
        <div style={{ paddingTop: "var(--space-small)" }}>{activeItem.content}</div>
      )}
    </div>
  );
}
