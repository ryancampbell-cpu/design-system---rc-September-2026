# Tabs

Underline tab bar. 2px ink rule on the active tab; muted labels otherwise.

```jsx
<Tabs
  defaultValue="publications"
  items={[
    { id: "publications", label: "Publications", content: <PubList /> },
    { id: "trials",       label: "Trials",       content: <TrialList /> },
  ]}
/>
```
