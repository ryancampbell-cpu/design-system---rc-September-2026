import React, { useState } from "react";

/** Colors section — click a swatch to copy its hex. */
export function Colors() {
  const [copied, setCopied] = useState(null);
  const copy = (hex) => {
    if (navigator.clipboard) navigator.clipboard.writeText(hex);
    setCopied(hex);
    setTimeout(() => setCopied(null), 1200);
  };
  const core = [
    { name: "Sapphire",    hex: "#064997", rgb: "6, 73, 151"   },
    { name: "Plum",        hex: "#8F1752", rgb: "143, 23, 82"  },
    { name: "Medium Gray", hex: "#636D7B", rgb: "99, 109, 123" },
  ];
  const blue = ["#003B80","#175CAD","#3B77BE","#6E9CD0","#A7C7EC","#C4DBF5","#D9EBFE","#EFF6FF"];
  const plum = ["#7C003D","#9B255F","#B14179","#D67DA8","#E7A0C3","#F0C8DC","#F9DDE9","#FFF2F9"];

  const Ramp = ({ list }) => (
    <div style={{ display: "flex", flexDirection: "column" }}>
      {list.map(hex => (
        <button
          key={hex}
          onClick={() => copy(hex)}
          style={{
            display: "flex", justifyContent: "space-between", alignItems: "center",
            border: "none", background: "transparent", cursor: "pointer",
            padding: "0 0 8px", width: "100%",
          }}
        >
          <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--text-muted)" }}>
            {copied === hex ? "Copied!" : `HEX: ${hex}`}
          </span>
          <span style={{ width: "50%", minHeight: "2.5rem", background: hex }} />
        </button>
      ))}
    </div>
  );

  return (
    <section id="colors" style={{ padding: "5rem 0" }}>
      <div style={{ maxWidth: "80rem", margin: "0 auto", padding: "0 3.75rem" }}>
        <div style={{ borderBottom: "3px solid var(--color-neutral-900)", paddingBottom: "1rem", marginBottom: "3rem" }}>
          <h2 style={{ margin: 0 }}>Colors</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "1.25rem", marginBottom: "2rem" }}>
          {core.map(c => (
            <div key={c.name} onClick={() => copy(c.hex)} style={{ cursor: "pointer" }}>
              <div style={{ minHeight: "11.25rem", background: c.hex }} />
              <h4 style={{ margin: "1rem 0 .5rem" }}>{c.name}</h4>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--text-muted)", lineHeight: 1.5 }}>
                {copied === c.hex ? "Copied!" : <>HEX: {c.hex}<br />RGB: {c.rgb}</>}
              </div>
            </div>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.25rem" }}>
          <Ramp list={blue} />
          <Ramp list={plum} />
        </div>
      </div>
    </section>
  );
}
