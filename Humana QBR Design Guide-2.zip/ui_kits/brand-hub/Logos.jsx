import React from "react";
import { Button } from "../../components/buttons/Button.jsx";

/** Three logo lockups with faux download links, from the brand hub source. */
export function Logos() {
  const cards = [
    { name: "Sapphire",  src: "../../assets/logo-sapphire.svg",  bg: "#fff",                    border: true  },
    { name: "White",     src: "../../assets/logo-white.svg",     bg: "var(--color-sapphire)",   border: false },
    { name: "Grayscale", src: "../../assets/logo-grayscale.svg", bg: "#fff",                    border: true  },
  ];
  return (
    <section id="logos" style={{ padding: "5rem 0" }}>
      <div style={{ maxWidth: "80rem", margin: "0 auto", padding: "0 3.75rem" }}>
        <div style={{ borderBottom: "3px solid var(--color-neutral-900)", paddingBottom: "1rem", marginBottom: "3rem" }}>
          <h2 style={{ margin: 0 }}>Logos</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "1.25rem" }}>
          {cards.map(c => (
            <div key={c.name} style={{ display: "flex", flexDirection: "column" }}>
              <div style={{
                display: "flex", alignItems: "center", justifyContent: "center",
                minHeight: "13.875rem", padding: "0 3.5rem",
                background: c.bg, border: c.border ? "1px solid var(--border-default)" : "none",
              }}>
                <img src={c.src} alt={`H1 logo — ${c.name}`} style={{ maxHeight: "4.6875rem" }} />
              </div>
              <h5 style={{ margin: "1.5rem 0 1rem" }}>{c.name}</h5>
              <div style={{ display: "flex", gap: "2rem" }}>
                <Button variant="tertiary" size="small" href="#" onClick={(e)=>e.preventDefault()}>Download PNG</Button>
                <Button variant="tertiary" size="small" href="#" onClick={(e)=>e.preventDefault()}>Download SVG</Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
