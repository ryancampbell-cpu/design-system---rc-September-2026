import React from "react";

/** Bordered 3-column identity grid — sapphire labels absolutely positioned. */
export function VisualIdentity({ onJump }) {
  const S = "var(--color-sapphire)";
  const items = [
    { label: "Logos", target: "logos", render: () => <img src="../../assets/logo-sapphire.svg" alt="" style={{ maxHeight: 64 }} /> },
    { label: "Color & Typography", target: "colors", render: () => (
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
        <div style={{ display: "flex", gap: 6 }}>
          {["#064997","#8f1752","#636d7b","#a7c7ec"].map(c => (
            <span key={c} style={{ width: 26, height: 26, background: c }} />
          ))}
        </div>
        <div style={{ fontFamily: "var(--font-display)", fontSize: 26, color: "var(--color-neutral-900)" }}>Aa</div>
      </div>
    )},
    { label: "Photography", target: "photography", render: () => <img src="../../assets/hero-brand-photo.webp" alt="" style={{ maxWidth: "100%", maxHeight: 110, borderRadius: 12, objectFit: "cover" }} /> },
    { label: "Illustration", target: "illustration", render: () => (
      <div style={{ display: "flex", gap: 12 }}>
        <img src="../../assets/illus-eye.png" alt="" style={{ maxHeight: 96 }} />
        <img src="../../assets/illus-uncover.png" alt="" style={{ maxHeight: 96 }} />
      </div>
    )},
    { label: "Components", target: "components", render: () => (
      <div style={{ fontFamily: "var(--font-display)", fontSize: 22, color: "var(--color-neutral-900)" }}>Buttons · Cards</div>
    )},
    { label: "Tokens", target: "tokens", render: () => (
      <code style={{ fontFamily: "ui-monospace, Menlo, monospace", fontSize: 13, color: "var(--color-neutral-900)", textAlign: "center", lineHeight: 1.6 }}>
        --color-sapphire<br />--font-display<br />--space-medium
      </code>
    )},
  ];
  return (
    <section style={{ padding: "5rem 0", overflow: "hidden" }}>
      <div style={{ maxWidth: "80rem", margin: "0 auto", padding: "0 3.75rem" }}>
        <h2 style={{ marginBottom: "3rem" }}>Visual Identity</h2>
        <div style={{
          display: "grid", gridTemplateColumns: "1fr 1fr 1fr",
          border: `2px solid ${S}`, borderRight: "none", borderBottom: "none",
        }}>
          <div style={{
            gridColumn: "1 / -1", padding: "2.5rem 2rem",
            borderRight: `2px solid ${S}`, borderBottom: `2px solid ${S}`,
          }}>
            <h3 style={{ color: S, margin: 0, maxWidth: "22rem" }}>
              Brand elements that define the H1 visual identity
            </h3>
          </div>
          {items.map((it) => (
            <button
              key={it.label}
              onClick={() => onJump && onJump(it.target)}
              style={{
                position: "relative", minHeight: 200, border: "none",
                borderRight: `2px solid ${S}`, borderBottom: `2px solid ${S}`,
                background: "transparent", cursor: "pointer",
                padding: "4rem 2rem 2rem",
                display: "flex", alignItems: "center", justifyContent: "center",
                transition: "background .25s",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "var(--color-blue-50)")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
            >
              <h4 style={{ position: "absolute", top: "1.5rem", left: "2rem", margin: 0, color: S }}>{it.label}</h4>
              {it.render()}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
