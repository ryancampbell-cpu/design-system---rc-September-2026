import React from "react";

/** H1 Brand Hub — hero. Sapphire full-bleed, white logo, overlay photograph. */
export function Hero() {
  return (
    <section id="top" style={{
      position: "relative", background: "var(--color-sapphire)",
      minHeight: 600, display: "flex", alignItems: "center", overflow: "hidden",
    }}>
      <img src="../../assets/hero-brand-photo.webp" alt="" style={{
        position: "absolute", inset: 0, width: "100%", height: "100%",
        objectFit: "cover", mixBlendMode: "overlay",
      }} />
      <div style={{
        position: "relative", zIndex: 1,
        maxWidth: "80rem", width: "100%", margin: "0 auto", padding: "0 3.75rem",
      }}>
        <img src="../../assets/logo-white.svg" alt="H1" style={{ height: 84, marginBottom: "3rem" }} />
        <div style={{ maxWidth: "28.5rem", marginBottom: "1.875rem" }}>
          <h1 style={{
            color: "#fff", margin: 0,
            fontSize: "3.875rem", lineHeight: "4.5625rem",
            fontFamily: "var(--font-display)", fontWeight: 400,
          }}>
            Welcome to the H1 Brand Hub
          </h1>
        </div>
        <div style={{ maxWidth: "27.875rem" }}>
          <p style={{ color: "#fff", fontFamily: "var(--font-body)", fontSize: "1.25rem", margin: 0 }}>
            This site serves as a resource to help you navigate H1 brand standards
            and expectations as we become a more unified organization.
          </p>
        </div>
      </div>
    </section>
  );
}
