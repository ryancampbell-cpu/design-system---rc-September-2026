# Brand Hub UI kit

A hi-fi recreation of the H1 Brand Hub landing surface (`brand.h1.co`), composed from the design system's own primitives.

## Screens

- **index.html** — one-page brand hub: hero + Visual Identity grid + Logos + Colors + Typography + a demo of the component set. All copy, imagery and layout values come from the standalone brand-kit source that seeded this project; no invented content.

## What this covers

- `Hero.jsx` — sapphire full-bleed with reversed logo and overlay photograph.
- `VisualIdentity.jsx` — bordered 3-column grid, sapphire labels absolutely positioned in each cell.
- `Logos.jsx` — three logo lockups (Sapphire, White, Grayscale) with faux download links.
- `Colors.jsx` — click-to-copy swatches for the core trio and the blue/plum ramps.

Component recreations pull from `window.HumanaQBRDesignGuide_4ec619` (Button etc.). Icon glyphs are the only piece not represented: the commercial H1 secondary icon PNGs are not part of the shipped kit.
